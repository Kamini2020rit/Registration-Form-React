import {useState ,useEffect} from 'react';
import './App.css';
import React from 'react';


function App() {

    const initvalues={
    UserName: "",
    Email: "",
    MobileNo: "",
    NewPassword: "",
    ConfirmPassword: "",
  };

  const[formValues,setFormValues]=useState(initvalues);
  const[formErrors,setFormErrors]=useState({});
  const [isSubmit, setisSubmit] = useState(false);
  
  //console.log(UserName)
  
    const handleSubmit = (e) => {
      e.preventDefault();
      setFormErrors(validate(formValues));
      setisSubmit(true);
    };

    useEffect(() =>{
    console.log(formErrors);
      if(Object.keys(formErrors).length === 0 && isSubmit){
          console.log(formValues);
      }
    },[formErrors,formValues,isSubmit]);
        
  
  const handleChange = (e) => {
    const { name,value }=e.target;
      setFormValues({...formValues, [name] : value});
      
    };

//console.log(values);

  const validate = (value) =>{

    const errors={};
    const use=/^[A-Za-z0-9 ]{8,16}/
    const em=/^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/
    const ph=/^[0-9]{10}$/
    const  pass=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,}$/

    if(use.test(value.UserName)){
      if(em.test(value.Email)){
        if(ph.test(value.MobileNo)){
          if(pass.test(value.NewPassword)){
            if(value.ConfirmPassword === value.NewPassword){
              alert("Registration successful");
              value.UserName="";
              value.Email="";
              value.MobileNo="";
              value.NewPassword="";
              value.ConfirmPassword="";
            }
            else if (value.ConfirmPassword ===""){
              alert("Password confirmation is required");
            } else {
              alert("Password doesn't matches");
            }
          }
          else if(value.NewPassword === ""){
            alert("Password is required");
          }
          else if(!pass.test(value.NewPassword)){
            alert("Password isn't Strong");
          }
        }
        else if(value.MobileNo === ""){
          alert("Mobile number is required");
        }
        else if(!ph.test(value.MobileNo)){
          alert("Mobile number is not valid");
        }
      }
      else if(value.Email === ""){
        alert("Email ID is required");
      }
      else if(!em.test(value.Email)){
        alert("Email ID isn't valid");
      }
    }
    else if(value.UserName === ""){
      alert("Username is required");
    }
    else if(!use.test(value.UserName)){
      alert("Username should be of 8-16 characters");
    }
    return errors;
  };

  return (
  <div className='App'>
    <form onSubmit={handleSubmit}>
      <h1>Registration Form</h1>
      <div className='ui form'>
          <div className='field'>
            <label>UserName</label>
            <input 
                  name='UserName'
                  type="text"
                  placeholder="username" 
                  value={formValues.UserName} 
                  onChange={handleChange} >
                  </input>
          </div>
         
          <div className='field'>
          <label>Email</label>
            <input 
                  name='Email'
                  type="text"
                  placeholder="email" 
                  value={formValues.Email} onChange={handleChange} >
                  </input>
            </div>
          
            <div className='field'>
          <label>MobileNo</label>
            <input 
                  name='MobileNo'
                  type="phonenumber"
                  placeholder="Mobileno" 
                  value={formValues.MobileNo} onChange={handleChange} >
                  </input>
            </div>

            <div className='field'>
          <label>NewPassword</label>
            <input 
                  name='NewPassword'
                  type="text"
                  placeholder="NewPassword" 
                  value={formValues.NewPassword} onChange={handleChange} >
                  </input>
            </div>

            <div className='field'>
          <label>ConfirmPassword</label>
            <input 
                  name='ConfirmPassword'
                  type="text"
                  placeholder="ConfirmPassword" 
                  value={formValues.ConfirmPassword} onChange={handleChange} >
                  </input>
            </div>
          <button className='button'>Submit</button>
        </div>
        
    </form>
  </div>
  );
};

export default App;
